<?php
    require "partials/header.php"
?>
    
    <section id="pageCover" class="row servicePage">
        <div class="row pageTitle">Services</div>
        <div class="row pageBreadcrumbs">
            <ol class="breadcrumb">
              <li><a href="index.php">acceuil</a></li>
              <li class="active">services</li>
            </ol>
        </div>
    </section>
    
    <section id="services" class="row">
        <div class="container">
            <div class="row">
                <div class="col-sm-9">
                    <div class="row">
                        <div class="row m0 whyUs">
                            <div class="col-sm-12">
                                <div class="row m0 whyUsInner">
                                    <div class="col-sm-7">
                                        <h3>Pourquoi nous ? <i class="fa fa-question"></i></h3>
                                        <p>le but de cette entreprise est de fournir du confort et du bien-être aux ménages et aux individus, ainsi que d'améliorer la qualité de vie. Elle fournit des services qui aident à améliorer l'environnement et à économiser de l'énergie.</p>
                                    </div>
                                    <div class="col-sm-5">
                                    <ul class="list-inline tagFeatures">
                                            <li><span class="badge"><i class="fa fa-check"></i></span>Service client 24/7 </li>
                                            <li><span class="badge"><i class="fa fa-check"></i></span> Gain de temps et de confort</li>
                                            <li><span class="badge"><i class="fa fa-check"></i></span> Renouvellement</li>
                                            <li><span class="badge"><i class="fa fa-check"></i></span>Protection optimale</li>
                                            <li><span class="badge"><i class="fa fa-check"></i></span> Maximisation de l'efficacité</li>
                                            <li><span class="badge"><i class="fa fa-check"></i></span> Meilleure qualité de service</li>
                                            <li><span class="badge"><i class="fa fa-check"></i></span> Sécurité garantie</li>
                                        </ul>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row m0 whatOffer" id="prestation">
                            <div class="col-sm-12">
                                <div class="row m0 whatOfferInner">
                                    <h3>Ce que nous offrons</h3>
                                    <span class="fleft bigLetter">P</span> <span>restation</span>  
                                    désigne le service qui est fourni pour la rénovation domiciliaire, qui est précisé dans le contrat entre le client et le prestataire. <br>Le service peut inclure la rénovation de la cuisine, la rénovation de la salle de bain, la rénovation du sol, la rénovation des murs et d'autres services.
                                </div>
                            </div>
                        </div>
                        <div class="row m0 whatOffer" id="electricite">
                            <div class="col-sm-12">
                                <div class="row m0 whatOfferInner">
                                    <span class="fleft bigLetter">E</span> <span>lecricité de Dépannage et Installation</span>  
                                    il s'agit d'un service qui comprend l'installation de câblages électriques et d'autres composants électriques dans les maisons, les bâtiments commerciaux et industriels. Ce service comprend également la réparation des pannes électriques et la fourniture d'entretien régulier des systèmes électriques. <br> Ce service est fourni par des experts en électricité qui possèdent les connaissances et l'expérience nécessaires pour fournir un service de haute qualité et en toute sécurité.
                                </div>
                            </div>
                        </div>
                        <div class="row m0 whatOffer" id="plomberie">
                            <div class="col-sm-12">
                                <div class="row m0 whatOfferInner">
                                    <span class="fleft bigLetter">P</span> <span>lomberie de Dépannage et Installation</span>  
                                    notre service de plomberie complet répond à tous vos besoins. Que ce soit pour des problèmes de fuites, des installations sanitaires ou des dépannages urgents, notre équipe expérimentée est là pour vous.<br> Nous offrons des solutions rapides et efficaces, garantissant une plomberie fiable et fonctionnelle. Faites confiance à nos experts en plomberie pour des résultats de haute qualité et une satisfaction client maximale pour résoudre efficacement tous vos problèmes de plomberie.
                                </div>
                            </div>
                        </div>
                        
                        <div class="row m0 whatOffer" id="climatisation">
                            <div class="col-sm-12">
                                <div class="row m0 whatOfferInner">
                                    <span class="fleft bigLetter">C</span> <span>limatisation</span>  
                                    le système de climatisation, qui est utilisé pour améliorer la qualité de l'air et réguler la température dans les maisons, les bâtiments ou les véhicules. Le système est généralement installé dans les murs ou les plafonds tel qu'il est ainsi utilisé pour refroidir l'air pendant les jours chauds et le réchauffer pendant les jours froids.<br> L'installation et la maintenance de ce système nécessitent des compétences et une connaissance approfondie en génie mécanique, électrique et de la réfrigération.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <aside class="col-sm-3 sidebar">
                    <div class="row m0 recentPostWidget widgetS">
                        <h4>Recent Posts</h4>
                        <div class="row m0 recentblogs">
                            <div class="media recentblog">
                                <div class="media-left">
                                    <a href="#">
                                        <img class="media-object" src="images/blog/recent1.png" alt="">
                                    </a>
                                </div>
                                <div class="media-body">
                                    <a href="#"><h5 class="media-heading">This is PhotoShop's version of Lorem Ipsum</h5></a>
                                </div>
                            </div>
                            <div class="media recentblog">
                                <div class="media-left">
                                    <a href="#">
                                        <img class="media-object" src="images/blog/recent2.png" alt="">
                                    </a>
                                </div>
                                <div class="media-body">
                                    <a href="#"><h5 class="media-heading">This is PhotoShop's version of Lorem Ipsum</h5></a>
                                </div>
                            </div>
                            <div class="media recentblog">
                                <div class="media-left">
                                    <a href="#">
                                        <img class="media-object" src="images/blog/recent3.png" alt="">
                                    </a>
                                </div>
                                <div class="media-body">
                                    <a href="#"><h5 class="media-heading">This is PhotoShop's version of Lorem Ipsum</h5></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row m0 contactWidget widgetS">
                        <h4>Contact us</h4>
                        <ul class="list-unstyled">
                            <li><i class="fa fa-phone"></i> +33 7 77 30 41 66</li>
                            <li><i class="fa fa-envelope"></i> contact@yourdomain.com</li>
                            <li><i class="fa fa-home"></i> 16 RUE ANATOLE FRANCE 95190 GOUSSAINVILLE</li>
                        </ul>
                    </div>
                </aside>
            </div>            
        </div>
    </section>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script>
$(document).ready(function(){
  $(".dropdown-menu a").on('click', function(event) {

    if (this.hash !== "") {
      event.preventDefault();
      var hash = this.hash;

      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 800, function(){

        window.location.hash = hash;
      });
    } 
  });
});
</script>


    <?php
    require "partials/footer.php"
    ?>